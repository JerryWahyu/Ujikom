<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>SPP Sekolah Merdeka</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="asset/assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../asset/css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">SPP Sekolah Merdeka</div>
                <div class="list-group list-group-flush">
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../index.php">Dashboard</a>                    
            
                    <div class="dropdown">
                        <a class="list-group-item list-group-item-action list-group-item-light p-3 dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">Entri Pembayaran Transaksi</a> 
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="pembayaran.php">Lihat Pembayaran</a></li>
                            <li><a class="dropdown-item" href="TambahPembayaran.php">Tambah Pembayaran</a></li>
                        </ul>
                    </div>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../history.php">History Pembayaran</a>    
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn btn-primary" id="sidebarToggle"><</button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">list</a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <?php
                                        include'../aset-web/topbar.php';
                                    ?>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
                <form method="post" action="api/TambahData.php">
                    <div class="container">
                    <a class="btn btn-primary mt-3" href="pembayaran.php" role="button">Back</a>
                        <div class="card-body">
                            <div class="card-text m-2">
                                <div class="form-group">
                                    <div class="row">
                                        <label class="col-md-2 h6">ID Pembayaran</label>
                                        <input type="text" name="Data1" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >ID Petugas</label>
                                    <select name="Data2" class="form-control">
                                    <option value="NO OPTION SELECT" selected>pilih petugas...</option>
                                        <?php
                                        include 'api/GetDP.php'
                                        ?>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >NISN</label>
                                <select name="Data3" class="form-control">
                                <option value="NO OPTION SELECT" selected>pilih NISN...</option>
                                        <?php
                                        include 'api/GetDP1.php'
                                        ?>
                                </select>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Tanggal Bayar</div>
                                        <input type="text" name="Data4" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >Bulan Bayar</label>
                                    <select name="Data5" class="form-control">
                                    <option value="NO VALUE" selected>pilih bulan...</option>
                                    <option value="januari">januari</option>
                                    <option value="febuari">Febuari</option>
                                    <option value="maret">Maret</option>
                                    <option value="april">april</option>
                                    <option value="mei">Mei</option>
                                    <option value="juni">Juni</option>
                                    <option value="juli">Juli</option>
                                    <option value="agustus">Agustus</option>
                                    <option value="september">September</option>
                                    <option value="oktober">Oktober</option>
                                    <option value="november">November</option>
                                    <option value="desember">Desember</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Tahun Bayar</div>
                                        <input type="text" name="Data6" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Jumblah Bayar</div>
                                        <input type="number" name="Data8" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <input href="" type="submit" class="btn btn-primary">
                                    </div>
                                </div>
                            </form>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="asset/js/scripts.js"></script>
    </body>
</html>
