<?php include('../header.php'); ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <a href="TambahPembayaran.php"  class="btn btn-primary" >Tambah Data Pembayaran</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item dropdown">
                                        <a href="../../logout.php"  class="btn btn-danger" >Logout</a> 
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
                <form method="post" action="api/TambahData.php">
                    <div class="container">
                    <a class="btn btn-primary mt-3" href="pembayaran.php" role="button">Back</a>
                        <div class="card-body">
                            <div class="card-text m-2">
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >ID Petugas</label>
                                    <select name="Data2" class="form-control">
                                    <option value="NO OPTION SELECT" selected>Pilih Petugas</option>
                                        <?php
                                        include 'api/GetDP.php'
                                        ?>
                                    </select>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >NISN</label>
                                    <select name="Data3" class="form-control">
                                    <option value="NO OPTION SELECT" selected>Pilih NISN</option>
                                            <?php
                                            include 'api/GetDP1.php'
                                            ?>
                                    </select>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Tanggal Bayar</div>
                                        <input type="text" name="Data4" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >Bulan Bayar</label>
                                    <select name="Data5" class="form-control">
                                    <option value="NO VALUE" selected>Pilih Bulan</option>
                                    <option value="januari">Januari</option>
                                    <option value="febuari">Febuari</option>
                                    <option value="maret">Maret</option>
                                    <option value="april">april</option>
                                    <option value="mei">Mei</option>
                                    <option value="juni">Juni</option>
                                    <option value="juli">Juli</option>
                                    <option value="agustus">Agustus</option>
                                    <option value="september">September</option>
                                    <option value="oktober">Oktober</option>
                                    <option value="november">November</option>
                                    <option value="desember">Desember</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Tahun Bayar</div>
                                        <input type="text" name="Data6" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Jumlah Bayar</div>
                                        <input type="number" name="Data8" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <input href="" type="submit" class="btn btn-primary">
                                    </div>
                                </div>
                            </form>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="asset/js/scripts.js"></script>
    </body>
</html>
