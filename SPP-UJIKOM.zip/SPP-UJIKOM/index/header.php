<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>SPP Sekolah MERDEKA</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="asset/assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../asset/css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">SPP Sekolah MERDEKA</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../index.php">
                        Dashboard
                    </a>                    
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../kelas/kelas.php"> 
                        kelas
                    </a>                    
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../petugas/petugas.php"> 
                        Petugas
                    </a>                    
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../siswa/siswa.php"> 
                        Siswa
                    </a>                    
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../spp/spp.php"> 
                        SPP
                    </a>                    
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../pembayaran/pembayaran.php"> 
                        Entri Transaksi Pembayaran
                    </a>                    
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../history/history.php"> 
                        History Pembayaran
                    </a>                    
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="../laporan/laporan.php"> 
                        Laporan SPP
                    </a>
                </div>
            </div>            
