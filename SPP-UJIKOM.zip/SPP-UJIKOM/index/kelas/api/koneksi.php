<?php
$hostname = "localhost";
$database = "spp";
$username = "root";
$password = "";

$kon = mysqli_connect($hostname, $username, $password, $database);

?>