<div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">SPP Sekolah ANIMEK</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Dashboard</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Kelas</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Pembayaran</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">petugas</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">siswa</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">SPP</a>
                </div>
            </div>