<?php include('../header.php'); ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <a href="TambahSiswa.php"  class="btn btn-primary" >Tambah Siswa</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item dropdown">
                                        <a href="../../logout.php"  class="btn btn-danger" >Logout</a> 
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
                <form method="post" action="PostData.php">
                    <div class="container">
                        <div class="card-body">
                            <div class="card-text m-2">
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">NISN</div>
                                        <input type="text" name="Data1" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">NIS</div>
                                        <input type="text" name="Data2" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Nama</div>
                                        <input type="text" name="Data3" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >Kelas</label>
                                <select name="Data4" class="form-control">
                                <option value="NO OPTION SELECT" selected>pilih Kelas...</option>
                                        <?php
                                        include 'GetDP1.php'
                                        ?>
                                </select>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">Alamat</div>
                                        <input type="text" name="Data5" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="row">
                                        <div class="col-md-2 h6">No Telepon</div>
                                        <input type="text" name="Data6" class="form-control col-md-8">
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-4 h6" >ID Spp</label>
                                <select name="Data7" class="form-control">
                                <option value="NO OPTION SELECT" selected>pilih Spp...</option>
                                        <?php
                                        include 'GetDP.php'
                                        ?>
                                </select>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <input href="siswa.php" type="submit" class="btn btn-primary">
                                    </div>
                                </div>
                            </form>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="asset/js/scripts.js"></script>
    </body>
</html>
